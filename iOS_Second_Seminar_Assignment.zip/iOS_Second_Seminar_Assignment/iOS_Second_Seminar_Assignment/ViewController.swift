//
//  ViewController.swift
//  iOS_Second_Seminar_Assignment
//
//  Created by Yoonsun Hwang on 2020/04/26.
//  Copyright © 2020 Yoonsun Hwang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBAction func moveNextView(_ sender: Any){
    }
    
}

